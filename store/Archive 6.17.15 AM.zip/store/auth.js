import { Container } from "unstated"
import AsyncStorage from '@react-native-community/async-storage';


class AuthContainer extends Container {
    state = {
        isAuthenticated: false,
        authToken: "",
        userId: null,
        userName: ""
    };

    checkAuthentication = async () => {
        const user = await AsyncStorage.getItem("user");
        if (user) {
            const parsedUser = JSON.parse(user);
            const { auth_token, user_id, user_login } = parsedUser;
            return this.setState(
                {
                    isAuthenticated: true,
                    authToken: auth_token,
                    userId: user_id,
                    userName: user_login

                })
        }
        return this.setState({ isAuthenticated: false })
    }

}

export { AuthContainer }