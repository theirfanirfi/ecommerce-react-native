
import { Visa, Maestro, MasterCard, Discover, Amex } from "../Images"

const images = {
    Visa, Maestro, MasterCard, Discover, Amex
}

export { images }